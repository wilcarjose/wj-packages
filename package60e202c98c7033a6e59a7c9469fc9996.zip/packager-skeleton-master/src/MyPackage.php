<?php

namespace :uc:vendor\:uc:package;

class :uc:package
{
    // Build wonderful things
}